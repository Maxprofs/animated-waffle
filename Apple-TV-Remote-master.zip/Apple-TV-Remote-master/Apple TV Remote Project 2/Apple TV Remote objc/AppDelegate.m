//
//  AppDelegate.m
//  Apple TV Remote objc
//
//  Created by Trent Rand on 1/5/15.
//  Copyright (c) 2015 applies, llc. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

@end
